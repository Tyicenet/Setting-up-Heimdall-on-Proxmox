# Setting up Heimdall on Proxmox

To install Heimdall on Proxmox PVE (which runs on Debian-based systems like Ubuntu), you can follow these steps. Heimdall is a web application dashboard that allows you to organize and manage various web apps from a single interface.

Here’s a step-by-step guide to install Heimdall on Proxmox PVE running Ubuntu (or Debian-based systems).

Under PVE0 or however you have it set up:

click “Create CT”

![image.png](image.png)

Fill in the nessesary informaiton:

![image.png](image%201.png)

Next

![image.png](image%202.png)

Next

![image.png](image%203.png)

Next

![image.png](image%204.png)

Next

![image.png](image%205.png)

We’ll need to change this to static once we get an ip

![image.png](image%206.png)

Next

![image.png](image%207.png)

Next

![image.png](image%208.png)

Finish

Log in:

Heimdall login: root

pw: $nakEEater-100

![image.png](image%209.png)

### 1. Update Your System

Before installing any new software, make sure your system is up-to-date. Run the following commands:

```bash
sudo apt update
sudo apt upgrade -y

```

### 2. Install Dependencies

Heimdall requires a few packages like Docker, Docker Compose, and a web server (like Nginx) to be installed. To begin, install Docker and Docker Compose if they aren't already installed.

### Install Docker

```bash

sudo apt install -y apt-transport-https ca-certificates curl software-properties-common curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/docker.gpg

sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

sudo apt update
sudo apt install -y docker-ce

# Install required dependencies
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common

# Add Docker’s official GPG key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/docker.gpg

# Add the Docker repository
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

# Update package index
sudo apt update

# Install Docker
sudo apt install -y docker-ce docker-ce-cli containerd.io

```

To check if Docker is installed correctly, run:

```bash

sudo systemctl status docker

```

If Docker is running, you will see a status message indicating that the service is active.

### Install Docker Compose

To install Docker Compose, you can download the latest version with the following command:

```bash

sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

```

Make it executable:

```bash

sudo chmod +x /usr/local/bin/docker-compose

```

Verify the installation:

```bash

docker-compose --version

```

### 3. Download Heimdall Docker Setup

Heimdall can be run in a Docker container. The official Heimdall Docker image is available on Docker Hub. To set it up, create a new directory where you’ll store the configuration and data:

```bash

mkdir -p ~/heimdall
cd ~/heimdall

```

Now, create a `docker-compose.yml` file in the `heimdall` directory:

```bash

nano docker-compose.yml

```

Add the following content to the `docker-compose.yml` file:

```yaml

version: '3'
services:
  heimdall:
    image: linuxserver/heimdall:latest
    container_name: heimdall
    environment:
      - PUID=1000
      - PGID=1000
    volumes:
      - ./config:/config
    ports:
      - "80:80"
    restart: unless-stopped

```

You can change the port number if 80 is already in use.

### 4. Start Heimdall Using Docker Compose

Once you’ve saved the `docker-compose.yml` file, you can start Heimdall with the following command:

```bash

docker-compose up -d

```

This will pull the `linuxserver/heimdall` image and run it in a container. The `-d` flag tells Docker Compose to run the container in the background.

### 5. Access Heimdall

Heimdall should now be running. To access it, open a web browser and navigate to the following URL (assuming you used port 80):

```arduino

http://<your-server-ip>

You should see the Heimdall dashboard.
```

### 6. Set Up Heimdall

After logging in, you can start adding your favorite web applications to the dashboard for easy access. The interface allows you to customize the layout and add links to the web apps you frequently use.

### 7. (Optional) Set Up SSL

If you want to secure your Heimdall installation with HTTPS, you can set up a reverse proxy using Nginx and enable SSL (using Let's Encrypt). Here's a basic guide on how to set up Nginx as a reverse proxy for Heimdall:

- Install Nginx:
    
    ```bash
    sudo apt install nginx
    
    ```
    
- Create a new Nginx configuration file for Heimdall:
    
    ```bash
    
    sudo nano /etc/nginx/sites-available/heimdall
    
    ```
    
    Add the following configuration:
    
    ```
    
    server {
        listen 80;
        server_name yourdomain.com;
    
        location / {
            proxy_pass http://localhost:80;  # Forward requests to Heimdall
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
    
    ```
    
- Enable the site and reload Nginx:
    
    ```bash
    
    sudo ln -s /etc/nginx/sites-available/heimdall /etc/nginx/sites-enabled/
    sudo systemctl reload nginx
    
    ```
    
- If you want to set up SSL using Let's Encrypt, you can use Certbot to obtain and install the certificate.

# Trouble shooting:

### 1. Check Docker Container Status

First, ensure the Heimdall container is actually running. You can check the status with the following command:

```bash
docker ps

```

This should list all running containers. Look for the `heimdall` container and verify that it's running. If it's not listed, try starting it manually:

```bash

docker-compose up -d

```

If there’s an issue starting Heimdall, you may want to check the logs for errors:

```bash

docker-compose logs

```

### 2. Check Ports and Firewall

If you’re trying to access Heimdall on port 80 and it’s not working, there might be a conflict with another service or a firewall blocking access.

- Verify that port 80 is open and not in use by another service with:
    
    ```bash
    sudo lsof -i :80
    
    ```
    
    If another process is using port 80, you can either stop that service or change the port number in the `docker-compose.yml` file. For example, change the port mapping to:
    
    ```yaml
    ports:
      - "8080:80"
    
    ```
    
    After changing the port, restart Heimdall:
    
    ```bash
    
    docker-compose down
    docker-compose up -d
    
    ```
    
- Ensure that your firewall allows traffic on the selected port. For UFW (Uncomplicated Firewall), use:
    
    ```bash
    
    sudo ufw allow 8080/tcp
    
    ```
    
    Replace `8080` with the port you configured in `docker-compose.yml`.
    

### 3. Check Logs for Errors

Look at the Heimdall container logs to see if there are any errors that could explain why it's not working:

```bash

docker-compose logs heimdall

```

If there’s an issue with the container or the web server inside, this might show up in the logs.

### 4. Verify Network Configuration

If you are running Heimdall on a remote server or virtual machine, ensure that the server’s IP address is correct and accessible from your browser. You can check the server's IP by running:

```bash
bash
Copy code
hostname -I

```

Make sure you are using the correct IP address when accessing Heimdall in your browser:

```bash
bash
Copy code
http://<your-server-ip>:8080

```

### 5. Check Docker and Compose Versions

Ensure that the versions of Docker and Docker Compose are up-to-date. Older versions might cause compatibility issues. Verify Docker's version:

```bash
bash
Copy code
docker --version

```

And Docker Compose’s version:

```bash
bash
Copy code
docker-compose --version

```

If they’re outdated, consider upgrading them:

```bash
bash
Copy code
sudo apt update
sudo apt upgrade docker-ce
sudo apt upgrade docker-compose

```

### 6. Verify Docker Container Health

Check if the container is healthy or if it has any issues related to the application:

```bash
bash
Copy code
docker inspect heimdall

```

Look for the `State` and `Health` sections to see if there’s a problem with the container’s health status.

### 7. Restart Docker Service

Sometimes, restarting Docker can help resolve issues with containers:

```bash
bash
Copy code
sudo systemctl restart docker

```

After restarting Docker, run `docker-compose up -d` again to restart Heimdall.